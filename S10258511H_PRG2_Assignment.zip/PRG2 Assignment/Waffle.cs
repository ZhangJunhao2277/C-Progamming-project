﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class Waffle : IceCream
    {
        private double SpecialWaffleAdditionalCost = 3.00; // Additional cost for special waffle flavors.

        public string WaffleFlavour { get; set; } // Flavor of the waffle cone.

        // Constructor to create a new Waffle with specified options.
        public Waffle(string option, int scoops, List<Flavour> flavours, List<Topping> toppings, string waffleFlavour)
            : base(option, scoops, flavours, toppings, 0) // Initialize the base class with a temporary total cost of 0.
        {
            WaffleFlavour = waffleFlavour; // Set the waffle flavor.
        }

        // Overrides the CalculatePrice method to calculate the price of the Waffle ice cream.
        public override double CalculatePrice()
        {
            double price = 0;

            // Calculate the base price based on the number of scoops.
            switch (Scoops)
            {
                case 1:
                    price += 7.00; // Single scoop
                    break;
                case 2:
                    price += 8.50; // Double scoop
                    break;
                case 3:
                    price += 9.50; // Triple scoop
                    break;
            }

            // Add the cost for premium flavors.
            foreach (var flavour in Flavours)
            {
                if (flavour.Premium)
                {
                    price += 2.00 * flavour.Quantity;
                }
            }

            // Add the cost for toppings.
            price += Toppings.Count;

            // Add the cost for a special waffle flavor, if applicable.
            if (!string.IsNullOrEmpty(WaffleFlavour) && (WaffleFlavour == "Red velvet" || WaffleFlavour == "Charcoal" || WaffleFlavour == "Pandan"))
            {
                price += SpecialWaffleAdditionalCost;
            }

            return price; // Return the calculated price.
        }
    }

}
