﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class Customer
    {
        // Customer's full name.
        public string Name { get; set; }

        // Unique membership ID.
        public int MemberId { get; set; }

        // Date of birth of the customer.
        public DateTime Dob { get; set; }

        // The current order being placed by the customer.
        public Order CurrentOrder { get; set; }

        // A history of orders placed by the customer.
        public List<Order> OrderHistory { get; set; }

        // The customer's rewards points and tier status.
        public PointCard Rewards { get; set; }

        // Constructor to create a new customer with a name, member ID, and date of birth.
        public Customer(string name, int memberId, DateTime dob)
        {
            Name = name;
            MemberId = memberId;
            Dob = dob;
            OrderHistory = new List<Order>(); // Initialize the list of orders
            Rewards = new PointCard(); // Initialize the rewards system
        }

        // Checks if today is the customer's birthday.
        public bool IsItBirthday()
        {
            // Compare today's month and day with the customer's date of birth.
            return DateTime.Today.Month == Dob.Month && DateTime.Today.Day == Dob.Day;
        }

        // Starts a new order for the customer.
        public void StartNewOrder(int orderId)
        {
            // Method to initiate a new order for the customer.
            if (CurrentOrder != null)
            {
                throw new InvalidOperationException("Unable to start a new order while one is in progress.");
            }
            CurrentOrder = new Order(orderId, DateTime.Now, this);
        }

        // Finalizes the current order and adds it to the order history.
        public void FinaliseOrder(Queue<Order> orderQueue, List<Order> currentOrdersList)
        {
            // Method to complete the current order and store it in the order history.
            if (CurrentOrder == null)
            {
                throw new InvalidOperationException("No order in progress to finalize.");
            }

            // Add the current order to the history.
            OrderHistory.Add(CurrentOrder);

            // Enqueue the order for further processing.
            orderQueue.Enqueue(CurrentOrder);
            currentOrdersList.Add(CurrentOrder);

            // Reset the current order after finalizing.
            CurrentOrder = null;
        }

        // Overrides the ToString method to provide a user-friendly string representation of the customer.
        public override string ToString()
        {
            return $"Customer: {Name}, ID: {MemberId}, DOB: {Dob.ToString("dd/MM/yyyy")}, Points: {Rewards.Points}, Tier: {Rewards.Tier}";
        }
    }

}

