﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class PointCard
    {
        // Properties to manage customer points, punch card, free ice cream credits, and membership tier.
        public int Points { get; set; }
        public int PunchCard { get; set; }
        public int FreeIceCreamCredit { get; private set; }
        public string Tier { get; set; }

        // Default constructor initializes with 0 points, punch card count, and ordinary tier.
        public PointCard()
        {
            Tier = "Ordinary";
        }

        // Constructor that initializes a new PointCard with points, punch card count, and tier.
        public PointCard(string tier, int points, int punchCard)
        {
            Tier = tier;
            Points = points;
            PunchCard = punchCard;
            UpdateTier(); // Update the membership tier based on points.
        }

        // Method to add points to the customer's card.
        public void AddPoints(int pointsToAdd)
        {
            if (pointsToAdd > 0)
            {
                Points += pointsToAdd; // Add points to the card.
                UpdateTier(); // Check if a tier upgrade is needed based on the new point balance.
            }
        }

        // Method to redeem points for rewards, returns true if successful, false otherwise.
        public bool RedeemPoints(int pointsToRedeem)
        {
            if (pointsToRedeem > 0 && Points >= pointsToRedeem)
            {
                Points -= pointsToRedeem; // Deduct points from the card.
                UpdateTier(); // Check if a tier downgrade is needed based on the new point balance.
                return true; // Points redeemed successfully.
            }
            return false; // Not enough points for redemption.
        }

        // Method to punch the punch card; awards free ice cream after 10 punches.
        public void Punch()
        {
            PunchCard++;
            if (PunchCard >= 10)
            {
                FreeIceCreamCredit++; // Award free ice cream credit.
                PunchCard = 0; // Reset the punch card.
            }
        }

        // Method to use a free ice cream credit if available, returns true if used, false otherwise.
        public bool UseFreeIceCreamCredit()
        {
            if (FreeIceCreamCredit > 0)
            {
                FreeIceCreamCredit--; // Use the free ice cream credit.
                return true; // Free ice cream credit used successfully.
            }
            return false; // No free ice cream credit available.
        }

        // Private method to update the membership tier based on points.
        private void UpdateTier()
        {
            if (Points < 50 && Tier != "Ordinary")
            {
                Tier = "Ordinary"; // Customer has less than 50 points, downgrade to Ordinary tier.
            }
            else if (Points >= 50 && Points < 100 && Tier != "Silver")
            {
                Tier = "Silver"; // Customer has 50-99 points, upgrade to Silver tier.
            }
            else if (Points >= 100 && Tier != "Gold")
            {
                Tier = "Gold"; // Customer has 100 or more points, upgrade to Gold tier.
            }
        }

        // Overrides the ToString method to provide a string representation of the PointCard.
        public override string ToString()
        {
            return $"PointCard: {Points} points, Tier: {Tier}, PunchCard: {PunchCard}, Free Ice Cream Credits: {FreeIceCreamCredit}";
        }
    }

}
