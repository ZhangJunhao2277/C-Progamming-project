﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class Cup : IceCream
    {
        // Base prices for single, double, and triple scoops.
        public double BasePriceSingle { get; set; } = 4.00;
        public double BasePriceDouble { get; set; } = 5.50;
        public double BasePriceTriple { get; set; } = 6.50;

        // Additional cost for premium flavors.
        public double PremiumFlavourAdditionalCost { get; set; } = 2.00;

        // Constructor to create a new Cup with options, scoops, flavors, and toppings.
        public Cup(string option, int scoops, List<Flavour> flavours, List<Topping> toppings)
            : base(option, scoops, flavours, toppings, CalculateInitialCost(scoops, flavours, toppings))
        { }

        // Method to calculate the initial total cost for the constructor.
        private static double CalculateInitialCost(int scoops, List<Flavour> flavours, List<Topping> toppings)
        {
            double initialCost = 0;

            // Determine the base price based on the number of scoops.
            if (scoops == 1)
            {
                initialCost = 4.00;
            }
            else if (scoops == 2)
            {
                initialCost = 5.50;
            }
            else if (scoops == 3)
            {
                initialCost = 6.50;
            }
            else
            {
                throw new ArgumentException("Invalid number of scoops. Please try again.");
            }

            // Add the cost for premium flavors.
            foreach (var flavour in flavours)
            {
                if (flavour.Premium)
                {
                    initialCost += 2.00 * flavour.Quantity;
                }
            }

            // Add a fixed cost for each topping, assuming each topping has a cost of 1 dollar.
            initialCost += toppings.Count * 1.00;

            return initialCost;
        }

        // Overrides the CalculatePrice method to return the total cost (converted to dollars) set during construction.
        public override double CalculatePrice()
        {
            return TotalCost;
        }
    }

}

