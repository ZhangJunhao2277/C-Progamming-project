﻿using PRG2_Assignment;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================
class Program
{
    private static DateTime dob;
    private static Queue<Order> orderQueue = new Queue<Order>();
    private static List<Order> currentOrdersList = new List<Order>();
    private static List<Order> orderList = new List<Order>();
    private static Queue<Order> goldMemberOrderQueue = new Queue<Order>();
    private static Queue<Order> regularOrderQueue = new Queue<Order>();
    private static List<IceCream> IceCreamList = new List<IceCream>();
    private static List<Customer> allCustomers = new List<Customer>();
    private static List<Flavour> flavours;
    private static List<Topping> toppings;
    private static List<IceCream> options;

    static void Main()
    {
        int option;

        string filePath = @"customers.csv";

        string optionsFilePath = "options.csv";
        string flavoursFilePath = "flavours.csv";
        string toppingsFilePath = "toppings.csv";
        string ordersFilePath = "orders.csv";
        flavours = ReadFlavoursFromCsv("flavours.csv");
        toppings = ReadToppingsFromCsv("toppings.csv");
        options = ReadOptionsFromCsv("options.csv", flavours, toppings);

        while (true)
        {
            // Display menu and options
            Console.WriteLine("Welcome to the Ice Cream Shop!");
            Console.WriteLine("\nPlease choose an option:");
            Console.WriteLine("[1] List all customers");
            Console.WriteLine("[2] List all current orders");
            Console.WriteLine("[3] Register a new customer");
            Console.WriteLine("[4] Create a customer's order");
            Console.WriteLine("[5] Display order details of a customer");
            Console.WriteLine("[6] Modify order details");
            Console.WriteLine("[7] Process an order and checkout");
            Console.WriteLine("[8] Display monthly charged amounts breakdown & total charged amounts for the year");
            Console.WriteLine("[0] Exit");

            try
            {
                option = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid number. Please enter number between 0 to 8.");
                continue;
            }

            if (option == 1)
            {
                List<Customer> customers = ReadCustomersFromCsv(filePath);
                DisplayAllCustomers(customers);
            }
            else if (option == 2)
            {
                Console.WriteLine("Gold Member Orders:");
                foreach (Order order in goldMemberOrderQueue)
                {
                    DisplayOrderInfo(order);
                }

                Console.WriteLine("\nRegular Orders:");
                foreach (Order order in regularOrderQueue)
                {
                    DisplayOrderInfo(order);
                }
            }
            else if (option == 3)
            {
                string name = GetCustomerName();
                int idNumber = GetCustomerId();

                Console.WriteLine($"Customer: {name}, ID: {idNumber}");
                bool isValidDate = false;
                Customer newCustomer = null;

                while (!isValidDate)
                {
                    // Prompt for customer's date of birth
                    Console.Write("Enter customer's date of birth (dd/MM/yyyy): ");
                    string dobInput = Console.ReadLine();

                    // Split the input string by the '/'.
                    string[] dateParts = dobInput.Split('/');

                    // Check that there is three parts and each part is the correct format: dd, MM, yyyy
                    if (dateParts.Length == 3 && dateParts[0].Length == 2 && dateParts[1].Length == 2 && dateParts[2].Length == 4)
                    {
                        try
                        {
                            // Convert each part to an integer
                            int day = Convert.ToInt32(dateParts[0]);
                            int month = Convert.ToInt32(dateParts[1]);
                            int year = Convert.ToInt32(dateParts[2]);

                            // Check if year, month, and day are in a valid range
                            if (year > 0 && month > 0 && month <= 12 && day > 0 && day <= DateTime.DaysInMonth(year, month))
                            {
                                // Create a DateTime object if the input is valid
                                dob = new DateTime(year, month, day);
                                isValidDate = true; // Set isValidDate to true, exiting the loop
                            }
                            else
                            {
                                Console.WriteLine("The date entered is not in an acceptable range.");
                            }
                        }
                        catch
                        {
                            Console.WriteLine("Invalid input. Enter in the correct format.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. Ensure you use the correct format (dd/mm/yyyy with slashes).");
                    }
                    newCustomer = new Customer(name, idNumber, dob); // Assign the new customer to 'newCustomer'
                    PointCard pointCard = new PointCard();
                    newCustomer.Rewards = pointCard; // Assign PointCard to the customer
                    AppendCustomerToCsv(newCustomer, filePath); // Append customer information to the CSV file
                    Console.WriteLine("Customer registered successfully.");
                }


            }


            else if (option == 4)
            {
                // Read data from CSV files
                List<Flavour> flavours = ReadFlavoursFromCsv(flavoursFilePath);
                List<Topping> toppings = ReadToppingsFromCsv(toppingsFilePath);
                List<IceCream> options = ReadOptionsFromCsv(optionsFilePath, flavours, toppings);

                // Display customers and select one
                List<Customer> customers = ReadCustomersFromCsv(filePath);
                DisplayAllCustomers(customers);

                Console.WriteLine("Please select a customer by ID:");
                int selectedCustomerId;

                while (true)
                {
                    string input = Console.ReadLine();

                    try
                    {
                        selectedCustomerId = Convert.ToInt32(input);
                        break; // Break out of the loop if conversion is successful
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Invalid input. Please enter a valid numeric ID:");
                    }
                }

                Customer selectedCustomer = GetCustomerById(customers, selectedCustomerId);

                if (selectedCustomer != null)
                {
                    Order order = new Order(selectedCustomerId, DateTime.Now, selectedCustomer);

                    Console.WriteLine($"Selected Customer ID: {selectedCustomer.MemberId}");

                    bool addMoreIceCream = true;
                    while (addMoreIceCream)
                    {
                        // Get user input for the ice cream order
                        IceCream iceCream = GetUserIceCreamOrder(options, flavours, toppings);
                        order.AddIceCream(iceCream); // Add the ice cream to the order
                        selectedCustomer.CurrentOrder = order;
                        Console.WriteLine("Are you adding another ice cream? (Y/optional, press enter to skip)");
                        addMoreIceCream = Console.ReadLine().Trim().ToLower() == "y";
                    }

                    currentOrdersList = EnqueueOrder(selectedCustomer, order, orderQueue, goldMemberOrderQueue, regularOrderQueue, currentOrdersList);

                    // Display a message to indicate the order has been made successfully
                    Console.WriteLine("Order has been placed successfully!");

                    // Display the order details
                    Console.WriteLine($"Order Details for Customer ID {selectedCustomer.MemberId}:");
                    Console.WriteLine($"Order Date: {order.TimeReceived}");
                    Console.WriteLine("Ice Creams:");

                    foreach (IceCream iceCream in order.IceCreamList)
                    {
                        Console.WriteLine(iceCream.ToString());
                    }
                }
                else
                {
                    Console.WriteLine($"No customer found with ID: {selectedCustomerId}. Please enter a valid ID.");
                }
            }


            else if (option == 5)
            {
                // Read customers list from CSV
                List<Customer> customers = ReadCustomersFromCsv(filePath);

                // Display the list of customers
                Console.WriteLine("List of Customers:");
                DisplayAllCustomers(customers);
                Console.WriteLine();

                int memId;

                do
                {
                    // Prompt user to enter the MemberId of the customer
                    Console.Write("Enter the MemberId of the customer: ");
                    if (!int.TryParse(Console.ReadLine(), out memId))
                    {
                        Console.WriteLine("Invalid Member ID.");
                        memId = -1; // entinel value to indicate an invalid input
                    }
                    else
                    {
                        // Retrieve the selected customer
                        Customer selectedCustomer = GetCustomerById(customers, memId);
                        if (selectedCustomer == null)
                        {
                            Console.WriteLine("Customer not found.");
                            memId = -1; // sentinel value to indicate a customer not found
                        }
                        else
                        {
                            // Display selected customer information
                            Console.WriteLine($"Selected Customer -> Member ID: {selectedCustomer.MemberId}, Name: {selectedCustomer.Name}, DOB: {selectedCustomer.Dob.ToString("dd/MM/yyyy")}");
                            Console.WriteLine();

                            // Display past orders
                            Console.WriteLine("Order Details (Past Orders):");
                            try
                            {
                                var orderLines = File.ReadAllLines(ordersFilePath).Skip(1).ToArray(); // Skip header
                                var orders = orderLines.Select(line => line.Split(',')).ToList();
                                var customerOrders = orders.Where(o => int.Parse(o[1]) == memId).ToList();

                                // Display all orders for the selected customer
                                foreach (var order in customerOrders)
                                {
                                    Console.WriteLine($"Order ID: {order[0]}, Received: {order[2]}, Fulfilled: {order[3]}, Option: {order[4]}, Scoops: {order[5]}, Dipped: {order[6]}");

                                    // Extract and display flavors and toppings
                                    var flavors = order.Skip(8).Take(3).Where(s => !string.IsNullOrWhiteSpace(s));
                                    var toppings = order.Skip(11).Take(4).Where(s => !string.IsNullOrWhiteSpace(s));

                                    Console.WriteLine($"Flavours: {string.Join(", ", flavors)}");
                                    Console.WriteLine($"Toppings: {string.Join(", ", toppings)}");
                                    Console.WriteLine();
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"An error occurred while reading past orders: {ex.Message}");
                            }

                            // Display all current orders for the selected customer
                            Console.WriteLine("Order Details (Current Orders):");
                            var currentOrders = currentOrdersList.Where(o => o.Customer.MemberId == memId).ToList();

                            if (currentOrders.Any())
                            {
                                foreach (Order order in currentOrders)
                                {
                                    DisplayOrderInfo(order);
                                }
                            }
                            else
                            {
                                Console.WriteLine("No current orders found for this customer.");
                            }
                        }
                    }
                } while (memId == -1); // Continue the loop if there's an error 
            }

            else if (option == 6)
            {
                bool selectingCustomer = true;
                while (selectingCustomer)
                {
                    List<Customer> customers = ReadCustomersFromCsv(filePath);
                    DisplayAllCustomers(customers);

                    Console.WriteLine("Select a customer by Member ID:");
                    if (!int.TryParse(Console.ReadLine(), out int selectedCustomerId))
                    {
                        Console.WriteLine("Invalid input. Please enter a valid Member ID.");
                        continue; // Skip the rest of the loop and start over
                    }

                    Customer selectedCustomer = GetCustomerById(customers, selectedCustomerId);
                    if (selectedCustomer == null)
                    {
                        Console.WriteLine("Customer not found. Try selecting another customer.");
                        continue; // Customer not found, start over the selection process
                    }

                    // Display selected customer information
                    Console.WriteLine($"Selected Customer -> Member ID: {selectedCustomer.MemberId}, Name: {selectedCustomer.Name}, DOB: {selectedCustomer.Dob.ToString("dd/MM/yyyy")}");
                    Console.WriteLine();

                    // Check for current orders
                    var currentOrders = currentOrdersList.Where(o => o.Customer.MemberId == selectedCustomerId).ToList();
                    if (!currentOrders.Any())
                    {
                        Console.WriteLine("No current orders found for this customer. Please try another customer.");
                        continue; // No current orders, prompt to try another customer
                    }

                    // Orders are present, proceed with displaying and modifying orders
                    foreach (Order order in currentOrders)
                    {
                        DisplayOrderInfo(order);
                    }

                    int subOption;
                    Console.WriteLine("[1] Modify Existing Order");
                    Console.WriteLine("[2] Add New Ice Cream to Order");
                    Console.WriteLine("[3] Delete Order");
                    Console.Write("Enter Option: ");
                    if (!int.TryParse(Console.ReadLine(), out subOption))
                    {
                        Console.WriteLine("Invalid input. Please enter a valid option.");
                        continue; // Invalid option, start over the selection process
                    }

                    switch (subOption)
                    {
                        case 1:
                            ModifyIceCream(currentOrdersList, selectedCustomer, flavours, toppings, options, goldMemberOrderQueue, regularOrderQueue);
                            break;
                        case 2:
                            AddNewIceCreamOrder(currentOrdersList, selectedCustomer, flavours, toppings, options);
                            break;
                        case 3:
                            DeleteCustomerOrder(currentOrdersList, selectedCustomer, goldMemberOrderQueue, regularOrderQueue);
                            break;
                        default:
                            Console.WriteLine("Invalid Option Entered.");
                            continue; // Invalid option, start over the selection process
                    }

                    
                    selectingCustomer = false;
                }
            }

            else if (option == 8)
            {
                Console.Write("Enter the year: ");
                if (!int.TryParse(Console.ReadLine(), out int inputYear))
                {
                    Console.WriteLine("Invalid input. Please enter a valid year.");
                }
                else
                {
                    var customers = ReadCustomersFromCsv(filePath); 

                    // Read orders and pass the customers list
                    var allOrders = ReadOrders(ordersFilePath, customers);

                    // Filter orders fulfilled in the input year
                    var yearlyOrders = allOrders.Where(order => order.TimeFulfilled?.Year == inputYear).ToList(); // Use ?. to handle nullable DateTime?

                    // Calculate total per month
                    var monthlyTotals = yearlyOrders
                        .GroupBy(order => order.TimeFulfilled?.Month)
                        .Where(group => group.Key.HasValue) // Filter out null months
                        .Select(group => new
                        {
                            Month = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(group.Key.Value),
                            Total = group.Sum(order => order.CalculateTotal()) 
                        })
                        .OrderBy(m => DateTime.ParseExact(m.Month, "MMMM", CultureInfo.CurrentCulture).Month)
                        .ToList();

                    // Display monthly totals
                    double yearlyTotal = 0;
                    foreach (var monthlyTotal in monthlyTotals)
                    {
                        Console.WriteLine($"{monthlyTotal.Month} {inputYear}: ${monthlyTotal.Total:F2}");
                        yearlyTotal += monthlyTotal.Total;
                    }

                    // Display yearly total
                    Console.WriteLine($"Total: ${yearlyTotal:F2}");
                }
            }






            else if (option == 0)
            {
                Console.WriteLine("Thank you for visiting! Goodbye.");
                break; // Exit the loop
            }
            else if (option == 7)
            {
                if (orderQueue.Count > 0)
                {
                    Order firstOrder = orderQueue.Dequeue();

                    if (firstOrder != null)
                    {
                        if (firstOrder.IceCreamList != null)
                        {
                            foreach (IceCream iceCream in firstOrder.IceCreamList)
                            {
                                Console.WriteLine(iceCream.ToString());
                            }

                            double totalBillAmount = firstOrder.CalculateTotal();
                            Console.WriteLine($"Total Bill Amount: {totalBillAmount}");

                            Customer customer = firstOrder.Customer;
                            Console.WriteLine($"Membership Status: {customer.Rewards.Tier}, Points: {customer.Rewards.Points}");

                            if (customer.IsItBirthday())
                            {
                                // Find the most expensive ice cream
                                IceCream mostExpensiveIceCream = null;
                                double maxPrice = 0;

                                foreach (IceCream iceCream in firstOrder.IceCreamList)
                                {
                                    double iceCreamPrice = iceCream.CalculatePrice();
                                    if (iceCreamPrice > maxPrice)
                                    {
                                        maxPrice = iceCreamPrice;
                                        mostExpensiveIceCream = iceCream;
                                    }
                                }

                                // Set the total cost of the most expensive ice cream to 0
                                if (mostExpensiveIceCream != null)
                                {
                                    mostExpensiveIceCream.TotalCost = 0;
                                }
                            }


                            if (customer.Rewards.PunchCard >= 10)
                            {
                                if (firstOrder.IceCreamList.Count > 0)
                                {
                                    firstOrder.IceCreamList[0].TotalCost = 0;
                                }
                                customer.Rewards.PunchCard = 0;
                            }

                            if (customer.Rewards.RedeemPoints((int)totalBillAmount))
                            {
                                if (customer.Rewards.Tier != "Ordinary")
                                {
                                    Console.WriteLine("How many points would you like to use?");
                                    int pointsToUse = Convert.ToInt32(Console.ReadLine());
                                    customer.Rewards.RedeemPoints(pointsToUse);
                                }
                                double finalTotalBillAmount = firstOrder.CalculateTotal();
                                Console.WriteLine($"Final Total Bill Amount after redeeming points: {finalTotalBillAmount}");
                            }
                            else
                            {
                                Console.WriteLine($"Final Total Bill Amount: {totalBillAmount}");
                            }

                            Console.WriteLine("Press any key to make your payment.");

                            foreach (IceCream iceCream in firstOrder.IceCreamList)
                            {
                                iceCream.TotalCost += 10;
                                if (iceCream.TotalCost > 10)
                                {
                                    iceCream.TotalCost = 10;
                                }
                            }

                            customer.Rewards.AddPoints((int)totalBillAmount);
                            firstOrder.TimeFulfilled = DateTime.Now;
                            customer.OrderHistory.Add(firstOrder);
                        }
                        else
                        {
                            Console.WriteLine("IceCreamList is null. No ice cream to process.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No order found.");
                    }
                }
                else
                {
                    Console.WriteLine("No orders in the queue.");
                }
            }
            else
            {
                Console.WriteLine("Invalid option. Please choose a number between 0 and 7.");
            }

            static string GetCustomerName()
            {
                Console.Write("Enter customer's name: ");
                return Console.ReadLine();
            }

            static int GetCustomerId()
            {
                int idNumber = 0;
                Console.Write("Enter customer's ID number: ");
                string idInput = Console.ReadLine();
                bool validInput = false;

                while (!validInput)
                {
                    try
                    {
                        idNumber = int.Parse(idInput); //  throws an exception for an invalid format
                        validInput = true;
                    }
                    catch (FormatException ex)
                    {
                        Console.WriteLine($"Invalid input. {ex.Message}");
                        Console.Write("Please enter a valid ID number: ");
                        idInput = Console.ReadLine(); // Prompt for input again
                    }
                }

                Console.WriteLine("ID number entered is valid.");
                return idNumber;
            }
        }


        static List<Customer> ReadCustomersFromCsv(string filePath)
        {
            List<Customer> customers = new List<Customer>();

            using (StreamReader reader = new StreamReader(filePath))
            {
                reader.ReadLine(); // Skip the header line.

                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] i = line.Split(',');  

                    if (i.Length < 6)
                    {
                        Console.WriteLine($"Line has fewer than 6 fields: {line}");
                        continue; // Skipgo to the next line
                    }

                    try
                    {
                        string name = i[0];
                        int memberId = Convert.ToInt32(i[1]);
                        DateTime dob = DateTime.ParseExact(i[2], "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        string membershipStatus = i[3];
                        int membershipPoints = Convert.ToInt32(i[4]);
                        int punchCard = Convert.ToInt32(i[5]);

                        Customer customer = new Customer(name, memberId, dob)
                        {
                            Rewards = new PointCard(membershipStatus, membershipPoints, punchCard)
                        };

                        customers.Add(customer);
                    }
                    catch (FormatException ex)
                    {
                        Console.WriteLine($"Formatting error occurred in this line '{line}': {ex.Message}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error occurred while processing this line '{line}': {ex.Message}");
                    }
                }
            }
            return customers;
        }


        static List<Customer> MergeCustomers(List<Customer> existingCustomers, List<Customer> newlyAppendedCustomers)
        {
            List<Customer> mergedCustomers = new List<Customer>();
            mergedCustomers.AddRange(existingCustomers);
            mergedCustomers.AddRange(newlyAppendedCustomers);
            return mergedCustomers;
        }


        
        static List<Order> EnqueueOrder(Customer customer, Order order, Queue<Order> orderQueue, Queue<Order> goldMemberOrderQueue, Queue<Order> regularOrderQueue, List<Order> currentOrdersList)
        {
            if (customer != null && order != null)
            {
                // Add the order to the current orders list
                currentOrdersList.Add(order);

                // Enqueue the order to the appropriate queue based on the customer's rewards tier
                if (customer.Rewards.Tier.ToLower() == "gold")
                {
                    goldMemberOrderQueue.Enqueue(order);
                    Console.WriteLine("Order added to the Gold Members' queue.");
                }
                else
                {
                    regularOrderQueue.Enqueue(order);
                    Console.WriteLine("Order added to the Regular Members' queue.");
                }

                // Enqueue the order to the general order queue
                orderQueue.Enqueue(order);
                Console.WriteLine($"Order for Customer ID {customer.MemberId} enqueued successfully.");
            }
            else
            {
                Console.WriteLine("Customer or order is null. Unable to enqueue order.");
            }

            // Return the updated currentOrdersList regardless of whether a new order was added
            return currentOrdersList;
        }


        static void DisplayAllCustomers(List<Customer> customers)
        {
            Console.WriteLine("--------------------------------------------------------------------------------------------------------");
            Console.WriteLine("|   Name            |   Member ID    |   DOB           |   Status    |   Points     |   Punch Card     |");
            Console.WriteLine("--------------------------------------------------------------------------------------------------------");

            foreach (Customer customer in customers)
            {
                Console.WriteLine($"|   {customer.Name,-15} |   {customer.MemberId,-12} |   {customer.Dob.ToString("dd/MM/yyyy"),-13} |   {customer.Rewards.Tier,-9} |   {customer.Rewards.Points,-10} |   {customer.Rewards.PunchCard,-14} |");
            }

            Console.WriteLine("--------------------------------------------------------------------------------------------------------");
        }


        static void AppendCustomerToCsv(Customer customer, string filePath)
        {
            // This is the line to be appended
            string newLine = $"{customer.Name},{customer.MemberId},{customer.Dob.ToString("dd/MM/yyyy")},{customer.Rewards.Tier},{customer.Rewards.Points},{customer.Rewards.PunchCard}";

            // Append the line to the file
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(newLine);
            }
        }


        static Customer GetCustomerById(List<Customer> customers, int customerId)
        {
            foreach (Customer customer in customers)
            {
                if (customer.MemberId == customerId)
                {
                    return customer;
                }
            }

            return null;
        }

        static List<IceCream> ReadOptionsFromCsv(string filePath, List<Flavour> flavours, List<Topping> toppings)
        {
            List<IceCream> iceCreams = new List<IceCream>();

            // Read all the lines into an array
            string[] lines = File.ReadAllLines(filePath);

            // Go through lines, starting from the second line to skip the header
            for (int j = 1; j < lines.Length; j++)
            {
                string[] fields = lines[j].Split(',');
                string optionName = fields[0];
                int basePrice = Convert.ToInt32(fields[1]);

                iceCreams.Add(new IceCream(optionName, 1, flavours, toppings, basePrice));
            }

            return iceCreams;
        }


        static List<Flavour> ReadFlavoursFromCsv(string filePath)
        {
            List<Flavour> flavours = new List<Flavour>();
            string[] lines = File.ReadAllLines(filePath);

            for (int i = 1; i < lines.Length; i++) // Skip the header line
            {
                string[] fields = lines[i].Split(',');
                string flavourName = fields[0];
                int extraCost = int.Parse(fields[1]);

                // Create a flavour object and add it to the list
                flavours.Add(new Flavour(flavourName, false, 1, extraCost));
            }

            return flavours;
        }


        static List<Topping> ReadToppingsFromCsv(string filePath)
        {
            List<Topping> toppings = new List<Topping>();

            // Read all lines into an array
            string[] lines = File.ReadAllLines(filePath);

            // Go through the lines, starting from the second line to skip the header
            for (int k = 1; k < lines.Length; k++)
            {
                // Process each data line
                string[] fields = lines[k].Split(',');
                string type = fields[0];
                double cost = double.Parse(fields[1]);
                toppings.Add(new Topping(type, cost));
            }

            return toppings;
        }


        static IceCream GetUserIceCreamOrder(List<IceCream> options, List<Flavour> flavours, List<Topping> toppings)
        {
            IceCream selectedIceCream = null;

            while (selectedIceCream == null)
            {
                try
                {
                    Console.WriteLine("Please enter the number of scoops:");
                    int scoops = int.Parse(Console.ReadLine());

                    while (scoops <= 0)
                    {
                        Console.WriteLine("Invalid number of scoops. Please enter a valid number:");
                        scoops = int.Parse(Console.ReadLine());
                    }

                    Console.WriteLine("Please choose your ice cream option by name(Cup, Cone, Waffle):");
                    string optionName = Console.ReadLine();

                    IceCream selectedOption = options.FirstOrDefault(option => option.Option == optionName);

                    if (selectedOption == null)
                    {
                        Console.WriteLine($"Invalid option name: '{optionName}'. Please try again.");
                        continue;
                    }

                    Console.WriteLine("Please choose a flavour by name(Vanilla, Chocolate, Strawberry, Durian, Ube, Sea salt):");
                    string flavourName = Console.ReadLine();

                    Flavour selectedFlavour = flavours.FirstOrDefault(flavour => flavour.Type == flavourName);

                    if (selectedFlavour == null)
                    {
                        Console.WriteLine($"Invalid flavour name: '{flavourName}'. Please try again.");
                        continue;
                    }

                    List<Topping> selectedToppings = new List<Topping>(); // Initialize selectedToppings as an empty list
                    Console.WriteLine("Please choose a topping by name(Sprinkles, Mochi, Sago, Oreos) (optional, press enter to skip):");
                    string toppingName = Console.ReadLine();

                    if (!string.IsNullOrWhiteSpace(toppingName))
                    {
                        Topping selectedTopping = toppings.FirstOrDefault(topping => topping.Type == toppingName);

                        if (selectedTopping != null)
                        {
                            selectedToppings.Add(selectedTopping); // Add selected topping to the list
                        }
                        else
                        {
                            Console.WriteLine($"Invalid topping name: '{toppingName}'. Try again.");
                            continue;
                        }
                    }

                    // Create a new ice cream object with the existing constructor
                    selectedIceCream = new IceCream(optionName, scoops, new List<Flavour> { selectedFlavour }, selectedToppings, 0); // Pass selectedToppings which could be empty but not null
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter a valid number.");
                }
            }

            return selectedIceCream;
        }


        static void DisplayOrderInfo(Order order)
        {
            if (order == null)
            {
                Console.WriteLine("Order is null.");
                return;
            }

            if (order.Customer == null)
            {
                Console.WriteLine("Order's customer is null.");
                return;
            }

            if (order.IceCreamList == null)
            {
                Console.WriteLine("Order's IceCreamList is null.");
                return;
            }

            //  access the properties of Order, Customer, and IceCreamList
            Console.WriteLine($"Order ID: {order.Id}");
            Console.WriteLine($"Customer: {order.Customer.Name}");
            Console.WriteLine($"Total Cost: {order.FinalTotal}");

            Console.WriteLine("Ice Creams in the Order:");
            foreach (IceCream iceCream in order.IceCreamList)
            {
                if (iceCream != null)
                {
                    Console.WriteLine($" - {iceCream.Option}, {iceCream.Scoops} scoops");

                    // Check if Flavours is not null before accessing it
                    var flavourNames = iceCream.Flavours != null ? string.Join(", ", iceCream.Flavours.Select(f => f.Type)) : "No flavours";
                    Console.WriteLine($"   Flavours: {flavourNames}");

                    // Check if Toppings is not null before accessing it
                    var toppingNames = iceCream.Toppings != null ? string.Join(", ", iceCream.Toppings.Select(t => t.Type)) : "No toppings";
                    Console.WriteLine($"   Toppings: {toppingNames}");
                }
                else
                {
                    Console.WriteLine(" - One of the ice cream items is null.");
                }
            }



            Console.WriteLine();
        }




        static List<Order> ReadOrders(string filePath, List<Customer> customers)
        {
            var orders = new List<Order>();
            var lines = File.ReadAllLines(filePath).Skip(1); // Skip the header row

            foreach (var line in lines)
            {
                var data = line.Split(','); // Columns are separated by commas

                int.TryParse(data[1], out int memberId);
                DateTime.TryParseExact(data[2], "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime timeReceived);
                DateTime.TryParseExact(data[3], "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime timeFulfilled);
                string option = data[4];
                int.TryParse(data[5], out int scoops);
                bool.TryParse(data[6], out bool dipped);
                string waffleFlavour = data[7];

                List<Flavour> flavours = new List<Flavour> {
            new Flavour(data[8], false, 1, 0),
            new Flavour(data[9], false, 1, 0),
            new Flavour(data[10], false, 1, 0)
        };

                List<Topping> toppings = new List<Topping> {
            new Topping(data[11], 0),
            new Topping(data[12], 0),
            new Topping(data[13], 0),
            new Topping(data[14], 0)
        };

                // Clean up empty flavour and topping entries
                flavours = flavours.Where(flavour => !string.IsNullOrEmpty(flavour.Type)).ToList();
                toppings = toppings.Where(topping => !string.IsNullOrEmpty(topping.Type)).ToList();

                var customer = customers.FirstOrDefault(c => c.MemberId == memberId);
                if (customer != null)
                {
                    IceCream iceCream;
                    switch (option.ToLower())
                    {
                        case "cup":
                            iceCream = new Cup(option, scoops, flavours, toppings);
                            break;
                        case "cone":
                            iceCream = new Cone(option, scoops, flavours, toppings, dipped, 0);
                            break;
                        case "waffle":
                            iceCream = new Waffle(option, scoops, flavours, toppings, waffleFlavour);
                            break;
                        default:
                            throw new InvalidOperationException($"Unknown ice cream option: {option}");
                    }

                    var order = new Order(memberId, timeReceived, customer);
                    order.AddIceCream(iceCream);
                    order.TimeFulfilled = timeFulfilled;
                    customer.OrderHistory.Add(order); // Add the order to the customer's history
                    orders.Add(order); // Add the order to the list of orders
                }
            }

            return orders;
        }

        static void ModifyIceCream(
    List<Order> currentOrdersList,
    Customer selectedCustomer,
    List<Flavour> flavours,
    List<Topping> toppings,
    List<IceCream> options,
    Queue<Order> goldMemberOrderQueue,
    Queue<Order> regularOrderQueue)
        {
            // Find the order for the selected customer
            Order existingOrder = currentOrdersList.FirstOrDefault(o => o.Customer.MemberId == selectedCustomer.MemberId);

            if (existingOrder != null)
            {
                // remove the existing order from the customer's queue
                if (selectedCustomer.Rewards.Tier.ToLower() == "gold")
                {
                    goldMemberOrderQueue = new Queue<Order>(goldMemberOrderQueue.Where(o => o.Id != existingOrder.Id));
                }
                else
                {
                    regularOrderQueue = new Queue<Order>(regularOrderQueue.Where(o => o.Id != existingOrder.Id));
                }

                // create a new order and add the ice creams
                Order newOrder = new Order(selectedCustomer.MemberId, DateTime.Now, selectedCustomer);
                bool addMoreIceCream = true;
                while (addMoreIceCream)
                {
                    IceCream newIceCream = GetUserIceCreamOrder(options, flavours, toppings);
                    newOrder.AddIceCream(newIceCream);
                    Console.WriteLine("Would you like to add another ice cream to the order? (yes/no):");
                    addMoreIceCream = Console.ReadLine().Trim().ToLower() == "yes";
                }

                // Replace the existing order with the new one in the currentOrdersList
                int index = currentOrdersList.IndexOf(existingOrder);
                currentOrdersList[index] = newOrder;

                // Enqueue the modified order to the appropriate queue
                if (selectedCustomer.Rewards.Tier.ToLower() == "gold")
                {
                    goldMemberOrderQueue.Enqueue(newOrder);
                }
                else
                {
                    regularOrderQueue.Enqueue(newOrder);
                }

                Console.WriteLine("Order has been modified and added to the list.");
            }
            else
            {
                Console.WriteLine("No order found for this customer to modify.");
            }
        }





        static void AddNewIceCreamOrder(List<Order> currentOrdersList, Customer selectedCustomer, List<Flavour> flavours, List<Topping> toppings, List<IceCream> options)
        {
            var order = currentOrdersList.FirstOrDefault(o => o.Customer.MemberId == selectedCustomer.MemberId);
            if (order != null)
            {
                IceCream newIceCream = GetUserIceCreamOrder(options, flavours, toppings);
                order.AddIceCream(newIceCream);
                Console.WriteLine("Added new ice cream to the existing order.");
            }
            else
            {
                Console.WriteLine("No order found for this customer to add a new ice cream.");
            }
        }


        static void DeleteCustomerOrder(
      List<Order> currentOrdersList,
      Customer selectedCustomer,
      Queue<Order> goldMemberOrderQueue,
      Queue<Order> regularOrderQueue)
        {
            var ordersToRemove = currentOrdersList
                .Where(o => o.Customer.MemberId == selectedCustomer.MemberId)
                .ToList();

            bool isRemoved = currentOrdersList.RemoveAll(o => o.Customer.MemberId == selectedCustomer.MemberId) > 0;

            if (isRemoved)
            {
                // Remove from gold member queue
                var tempQueue = new Queue<Order>();
                while (goldMemberOrderQueue.Count > 0)
                {
                    var order = goldMemberOrderQueue.Dequeue();
                    if (!ordersToRemove.Contains(order))
                    {
                        tempQueue.Enqueue(order);
                    }
                }
                goldMemberOrderQueue = tempQueue;

                // Remove from regular member queue
                tempQueue = new Queue<Order>();
                while (regularOrderQueue.Count > 0)
                {
                    var order = regularOrderQueue.Dequeue();
                    if (!ordersToRemove.Contains(order))
                    {
                        tempQueue.Enqueue(order);
                    }
                }
                regularOrderQueue = tempQueue;

                Console.WriteLine("The order has been deleted.");
            }
            else
            {
                Console.WriteLine("No order found for this customer.");
            }
        }


    }
}
