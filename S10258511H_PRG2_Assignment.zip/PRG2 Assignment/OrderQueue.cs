﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public static class OrderQueue
    {
        // Queues to store orders based on membership tier.
        private static Queue<Order> regularOrders = new Queue<Order>();
        private static Queue<Order> goldMemberOrders = new Queue<Order>();

        // Method to enqueue an order based on the customer's membership tier.
        public static void EnqueueOrder(Order order)
        {
            if (order.Customer.Rewards.Tier == "Gold")
            {
                goldMemberOrders.Enqueue(order); // Prioritize orders from gold members.
            }
            else
            {
                regularOrders.Enqueue(order); // Queue orders from regular members.
            }
        }

        // Method to dequeue the next order based on priority.
        public static Order DequeueNextOrder()
        {
            if (goldMemberOrders.Count > 0)
            {
                return goldMemberOrders.Dequeue(); // Attend to gold members' orders first.
            }
            if (regularOrders.Count > 0)
            {
                return regularOrders.Dequeue(); // Attend to regular members' orders.
            }
            return null; // Return null if no orders are left in the queues.
        }
    }


}
