﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class Cone : IceCream
    {
        // Additional cost for a chocolate-dipped cone.
        private const double DippedConeAdditionalCost = 2.00;

        // Indicates whether the cone is chocolate-dipped.
        public bool Dipped { get; set; }

        // Constructor to create a new Cone with options, scoops, flavors, toppings, and a flag for being dipped in chocolate.
        public Cone(string option, int scoops, List<Flavour> flavours, List<Topping> toppings, bool dipped, double totalCost)
            : base(option, scoops, flavours, toppings, totalCost)
        {
            Dipped = dipped;
            CalculatePrice();
        }

        // Overrides the CalculatePrice method to determine the price, including the base price and any additional cost for a chocolate-dipped cone.
        public override double CalculatePrice()
        {
            // Start with the base price calculation.
            double price = base.CalculatePrice();

            // Add the cost if the cone is chocolate-dipped.
            if (Dipped)
            {
                price += DippedConeAdditionalCost;
            }

            // Update the total cost.
            TotalCost = price;

            return price;
        }
    }

}
