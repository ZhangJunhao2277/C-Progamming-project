﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class Flavour
    {
        // The type or name of the flavor.
        public string Type { get; set; }

        // Indicates if the flavor is premium or regular.
        public bool Premium { get; set; }

        // The quantity or amount of this flavor.
        public int Quantity { get; set; }

        // The cost associated with this flavor.
        public double Cost { get; set; }

        // Constructor to create a new flavor with type, premium status, quantity, and cost.
        public Flavour(string type, bool premium, int quantity, double cost)
        {
            Type = type;
            Premium = premium;
            Quantity = quantity;
            Cost = cost;
        }

        // Overrides the ToString method to provide a user-friendly string representation of the flavor.
        public override string ToString()
        {
            return $"Flavour: {Type}, Premium: {Premium}, Cost: {Cost}";
        }
    }

}
