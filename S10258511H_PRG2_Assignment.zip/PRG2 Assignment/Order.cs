﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class Order
    {
        // Properties for order management.
        public int Id { get; set; }

        // The time when the order was received.
        public DateTime TimeReceived { get; set; }

        // The time when the order was fulfilled (if fulfilled).
        public DateTime? TimeFulfilled { get; set; }

        // A list of ice cream items in the order.
        public List<IceCream> IceCreamList { get; set; }

        // The customer who placed the order.
        public Customer Customer { get; private set; }

        // The final total price of the order.
        public double FinalTotal { get; private set; }

        // Constructor that initializes a new Order with an ID, the time it was received, and customer.
        public Order(int id, DateTime timeReceived, Customer customer)
        {
            Id = id;
            TimeReceived = timeReceived;
            Customer = customer;
            IceCreamList = new List<IceCream>();
            FinalTotal = 0;
        }

        // Method to add an ice cream item to the order.
        public void AddIceCream(IceCream iceCream)
        {
            if (iceCream == null)
            {
                throw new ArgumentNullException(nameof(iceCream), "Ice cream cannot be null.");
            }

            IceCreamList.Add(iceCream);
        }

        // Method to modify an existing ice cream item in the order.
        public void ModifyIceCream(int index, IceCream iceCream)
        {
            if (index < 0 || index >= IceCreamList.Count)
            {
                throw new ArgumentOutOfRangeException(nameof(index), "Index must be within the ice cream list.");
            }
            if (iceCream == null)
            {
                throw new ArgumentNullException(nameof(iceCream), "Ice cream cannot be null.");
            }

            IceCreamList[index] = iceCream;
        }

        // Method to remove an ice cream item from the order.
        public void DeleteIceCream(int index)
        {
            if (index < 0 || index >= IceCreamList.Count)
            {
                throw new ArgumentOutOfRangeException(nameof(index), "Index must be within the ice cream list.");
            }

            IceCreamList.RemoveAt(index);
        }

        // Method to calculate the total price of all ice cream items in the order.
        public double CalculateTotal()
        {
            double total = 0;
            foreach (var iceCream in IceCreamList)
            {
                total += iceCream.CalculatePrice(); // Add the price of each ice cream to the total.
            }
            FinalTotal = total; // Update final total 
            return FinalTotal;
        }

        // Method to apply a discount to the total price of the order.
        public void ApplyBirthdayDiscount(double discountAmount)
        {
            if (FinalTotal == 0) // Check if the final total has not been calculated before.
            {
                FinalTotal = CalculateTotal(); // Ensure the final total is calculated before applying a discount.
            }
            FinalTotal -= discountAmount; // Apply the discount to the final total.
            if (TimeFulfilled == null)
            {
                TimeFulfilled = DateTime.Now; // Optionally set time fulfilled, if this means order completion.
            }
        }

        // Overrides the ToString method to provide a user-friendly string representation of the Order.
        public override string ToString()
        {
            return $"Order ID: {Id}, Received: {TimeReceived}, Total: {FinalTotal:C}";
        }
    }

}
