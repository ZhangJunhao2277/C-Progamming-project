﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class Topping
    {
        // Properties to describe the topping type and its cost.
        public string Type { get; set; }
        public int Cost { get; set; } // Cost of the topping in dollars.

        // Constructor to initialize a new Topping with its type and cost.
        public Topping(string type, double cost)
        {
            Type = type;
            Cost = (int)cost; // Initialize the Cost property as an integer.
        }

        // Overrides the ToString method to provide a string representation of the Topping.
        public override string ToString()
        {
            return $"Topping: {Type}, Cost: {Cost:C}"; // Format the cost as a currency amount.
        }
    }

}
