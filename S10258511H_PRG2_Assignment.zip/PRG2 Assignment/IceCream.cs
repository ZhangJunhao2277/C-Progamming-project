﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//==========================================================
// Student Number : S10258511
// Student Name : Zhang Jun Hao
// Partner Name : Mariyln Fong
//==========================================================

namespace PRG2_Assignment
{
    public class IceCream
    {
        // The name or type of the ice cream option (e.g., Cup, Cone, Waffle).
        public string Option { get; set; }

        // The number of scoops of ice cream.
        public int Scoops { get; set; }

        // A list of flavors added to the ice cream.
        public List<Flavour> Flavours { get; set; }

        // A list of toppings added to the ice cream.
        public List<Topping> Toppings { get; set; }

        // The total cost of the ice cream.
        public double TotalCost { get; set; }

        // Initialize a new IceCream with option, scoops, flavors, toppings, and total cost.
        public IceCream(string option, int scoops, List<Flavour> flavours, List<Topping> toppings, double totalCost)
        {
            Option = option;
            Scoops = scoops;
            Flavours = flavours ?? new List<Flavour>();
            Toppings = toppings ?? new List<Topping>();
            TotalCost = totalCost; // Set the total cost.
        }

        // Virtual method to calculate the price. Subclasses can override this method.
        public virtual double CalculatePrice()
        {
            // Convert the TotalCost to a double and return it.
            return TotalCost;
        }

        // Overrides the ToString method to provide a user-friendly string representation of the IceCream.
        public override string ToString()
        {
            // Initialize empty strings for flavors and toppings
            string flavoursStr = "";
            string toppingsStr = "";

            // Loop through each Flavor and append the Type to flavoursStr
            for (int i = 0; i < Flavours.Count; i++)
            {
                if (Flavours[i] != null) // Check if the flavor object is not null
                {
                    flavoursStr += Flavours[i].Type;
                    if (i < Flavours.Count - 1) // Check if it's not the last flavor to add a comma and space
                    {
                        flavoursStr += ", ";
                    }
                }
            }

            // Loop through each topping and append the Type to toppingsStr
            for (int i = 0; i < Toppings.Count; i++)
            {
                if (Toppings[i] != null) // Check if the topping object is not null
                {
                    toppingsStr += Toppings[i].Type;
                    if (i < Toppings.Count - 1) // Check if it's not the last topping to add a comma and space
                    {
                        toppingsStr += ", ";
                    }
                }
            }

            // Construct the final string with the collected flavor and topping strings
            return $"Ice Cream: {Option}, Scoops: {Scoops}, Flavours: {flavoursStr}, Toppings: {toppingsStr}, Total Cost: {TotalCost:C}";
        }

    }

}
